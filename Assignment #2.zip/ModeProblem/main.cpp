/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March 19, 2012, 6:36 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

int *fillArray(int);
void printArray(int *,int,int);
int *destroyArray(int *);
int *sort(int *,int);

int main(int argc, char** argv) {
    //Fill Array
    const int SIZE=27;
    int *array=fillArray(SIZE);
    //Print the array
    printArray(array,SIZE,10);
    //Sort the array
    int *sorted=sort(array,SIZE);
    //Print the sorted array
    printArray(sorted,SIZE,10);
    //Find the max frequency
    int countF=0,maxFreq=0;
    for(int i=0;i<SIZE-1;i++){
        if(sorted[i]==sorted[i+1]){
            countF++;
            if(countF>maxFreq)maxFreq=countF;
        }else{
            countF=0;
        }
    }  
    //How many had the max Frequency
    //i.e. The number of modes =
    int nmodes=0;
    countF=0;
    for(int i=0;i<SIZE-1;i++){
        if(sorted[i]==sorted[i+1]){
            countF++;
            if(countF==maxFreq)nmodes++;
        }else{
            countF=0;
        }
    }
    //Fill the mode array
    int *mode=new int[nmodes+2];
    int acount=2;
    mode[0]=nmodes;
    countF=0;
    for(int i=0;i<SIZE-1;i++){
        if(sorted[i]==sorted[i+1]){
            countF++;
            if(countF==maxFreq)mode[acount++]=sorted[i];
        }else{
            countF=0;
        }
    }
    mode[1]=++maxFreq;
    //Print the results
    cout<<"The max Frequency = "<<maxFreq<<endl;
    cout<<"The number of modes = "<<nmodes<<endl;
    printArray(mode,nmodes+2,10);
    //Destroy the array
    destroyArray(array);
    destroyArray(sorted);
    return 0;
}

int *sort(int *a,int n){
    //Copy the array, then sort, and return
    int *b=new int[n];
    for(int i=0;i<n;i++){
        b[i]=a[i];
    }
    //Sort the array
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++)
            if(b[i]>b[j]){
                b[i]=b[i]^b[j];
                b[j]=b[i]^b[j];
                b[i]=b[i]^b[j];
            }
    }
    return b;
}

int *destroyArray(int *a){
    delete []a;
    return a;
}

int *fillArray(int n){
    int *a=new int[n];
    for(int i=0;i<n;i++){
        a[i]=i%10;
    }
    return a;
}
void printArray(int *a,int n,int p){
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%p==(p-1))cout<<endl;
    }
    cout<<endl;
}

