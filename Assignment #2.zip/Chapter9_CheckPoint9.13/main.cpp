/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 14, 2018, 11:00 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Chapter9_CheckPoint9.16 -9.16 Give an example of a function that correctly 
 * returns a pointer.*/


int main(int argc, char** argv) {
    
  
}

char *getInitials(){   
    char *initials = new char[3];   
    cout << "Enter your three initials: ";   
    cin >> initials[0] >> initials[1] >> initials[2];   
    return initials;
}