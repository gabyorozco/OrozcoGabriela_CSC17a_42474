#include <iostream>
#include <iomanip>
using namespace std;
//Write your funciton prototype here

void convert(double* x);

int main() {
 double mea;
 cout << "Enter a length in inches\n";
 cin >> mea;
 convert(&mea);
 cout << fixed << setprecision(4);
 cout << "Length in cenitmeters: " << mea << endl;
 return 0;
}
//Write the function convert here.
void convert(double* x) {
const double a = 2.54;
*x *= a;
}