/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on April 4, 2018, 4:33 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Complete the following program so it defines an array of Yard objects. The program
should use a loop to ask the user for the length and width of each Yard.  */

class Yard{
    private:
        int length, width;
    public:
        Yard()
            { length = 0; width = 0; }
        setLength(int len)
            { length = len; }
        setWidth(int w)
            { width = w; }
};

int main(int argc, char** argv) {
    Yard lawns[10];
    cout << "Enter the length and width of "
    << "each yard.\n";
 for (int count = 0; count < 10; count++){
    int input;
    cout << "Yard " << (count + 1) << ":\n";
    cout << "Length: ";
    cin >> input;
    lawns[count].setLength(input);
    cout << "width: ";
    cin >> input;
    lawns[count].setWidth(input);
 }

    return 0;
}

