/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on April 4, 2018, 3:30 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*Complete the following code skeleton to declare a class named Date. The class
should contain variables and functions to store and retrieve a date in the form
4/2/2014.
class Date
 {
 private:
 public:
 }*/
 


int main(int argc, char** argv) {
 
    
    
    
    class Date
{
private:
 int month;
 int day;
 int year;

public:
 // Mutators
 void setMonth(int m)
 { month = m; }
 void setDay(int d)
 { day = d; }
 void setYear(int y)
 { year = y; }
 // Accessors
 int getMonth() const
 { return month; }
 int getDay() const
 { return day; }
 int getYear() const
 { return year; }
};   
   
    
    
    
    
    
    
    
    
    
    
    return 0;
}
