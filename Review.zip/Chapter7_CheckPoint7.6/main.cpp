/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on February 26, 2018, 7:12 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/* CheckPoint7.6: What is the output of the following code. */

int main(int argc, char** argv) {
    
    int values[5], count;                   // This program outputs a numbers 1-5

    for (count = 0; count < 5; count++){
        values[count] = count + 1;
    }

    for (count = 0; count < 5; count++)
    cout << values[count] << endl;
    

    return 0;
}

