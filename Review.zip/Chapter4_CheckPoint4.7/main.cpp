/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: GabrilaOrozco
 *
 * Created on February 26, 2018, 6:50 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/* CheckPoint 4.7: Write an if statement that multiplies payRate by 1.5 if hours is greater than 40 */

int main(int argc, char** argv) {
    int payRate;
    int hours;
    
    if (hours > 40)
    {
        payRate *= 1.5;
    }

    
    return 0;
}

