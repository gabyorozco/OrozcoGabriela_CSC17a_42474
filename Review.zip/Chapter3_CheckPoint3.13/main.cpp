/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on February 26, 2018, 5:49 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*What will the following program display? */

int main(int argc, char** argv) {
 int integer1, integer2;
 double result;
 integer1 = 19;
 integer2 = 2;
 result = integer1 / integer2;
 cout << result << endl;
 result = static_cast<double>(integer1) / integer2;
 cout << result << endl;
 result = static_cast<double>(integer1 / integer2);
 cout << result << endl; 
    
 return 0;
}

