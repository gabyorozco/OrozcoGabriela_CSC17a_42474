/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: GabrielaOrozco
 *
 * Created on February 26, 2018, 6:59 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*CheckPoint 5.11: Write a for loop that displays every fifth number, zero through 100. */

int main(int argc, char** argv) {
    
    for (int num = 0; num <= 100; num+=5){
        cout << num << endl;
    }
    

    return 0;
}

