/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on February 26, 2018, 7:27 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*CheckPoint 8.7: The following program skeleton contains a 20-element array of int s called fish.
When completed, the program should ask how many fish were caught by fishermen
1 through 20, and store this data in the array. Complete the program. */

int main(int argc, char** argv) {
    const int NUM_FISH = 20;
    int fish[NUM_FISH];
    int count;
    cout << "Enter the number of fish caught\n";
    cout << "by each fisherman.\n";

    for (count = 0; count < NUM_FISH; count++)
    {
        cout << "fisherman " << (count+1) << ": ";
        cin >> fish[count];
    }
   
    h
    

    return 0;
}

