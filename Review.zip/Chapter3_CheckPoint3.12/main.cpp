/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabrielaOrozco
 *
 * Created on February 26, 2018, 5:13 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*CheckPoint3.12: Complete the following program skeleton so it asks the user to enter a character.
Store the character in the variable letter. Use a type cast expression with the
variable in a cout statement to display the character’s ASCII code on the screen.*/

int main(int argc, char** argv) {
    char letter;
    cout << "Enter letter: " << endl;
    cin >> letter;
    cout << static_cast<int>( letter) << endl;

    return 0;
}

