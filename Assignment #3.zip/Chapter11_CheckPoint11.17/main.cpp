/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 5:26 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Write the definition for an array of 50 of the ThreeTypes structures you declared
in Question 11.16. */


int main(int argc, char** argv) {
    union ThreeTypes{
        char letter;
        int whole;
        double real;
    };
ThreeTypes Items[50];
    return 0;
} 



