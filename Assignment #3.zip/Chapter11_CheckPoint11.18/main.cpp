/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 5:29 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

/* Write a loop that stores the floating point value 2.37 in all the elements of the
array you defined in Question 11.17*/


int main(int argc, char** argv) {
    union ThreeTypes{
        char letter;
        int whole;
        double real;
};
ThreeTypes Items[50];
for (int x = 0; x < 50; x++){
    Items[x].real = 2.37;
}
    return 0;
}



