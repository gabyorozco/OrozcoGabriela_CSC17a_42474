/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 5:38 PM
 */

#include <cstdlib>

using namespace std;

/*Write a loop that stores the character â€˜Aâ€™ in all the elements of the array you
defined in Question 11.17.*/


int main(int argc, char** argv) {
    union ThreeTypes{
        char letter;
        int whole;
        double real;
};
ThreeTypes Items[50];               
for (int x = 0; x < 50; x++)
    Items[x].real = 2.37;

for (int x = 0; x < 50; x++)        //11.19 part
    Items[x].letter = 'A';

    return 0;
}

