/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 5:01 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Write a function that accepts a Rectangle structure as its argument and displays
the structureâ€™s contents on the screen */



struct Rectangle
{
   int length;
   int width;
};

void displayRectangle(Rectangle rect)
{
   cout << endl;

   cout << "Length: " << rect.length << endl;
   cout << "Width: " << rect.width << endl;
}

void readRectangle(Rectangle &rect)
{
   cout << "Enter length: ";
   cin >> rect.length;

   cout << "Enter width: ";
   cin >> rect.width;
}

Rectangle getRectangle()
{
   Rectangle rect;

   cout << "Enter length: ";
   cin >> rect.length;

   cout << "Enter width: ";
   cin >> rect.width;

   return rect;
   
}

int main()
{
   cout << "Rectangle 1:" << endl;
   Rectangle rect1;
   readRectangle(rect1);
   displayRectangle(rect1);

   cout << "\n\nRectangle 2:" << endl;
   Rectangle rect2 = getRectangle();
   displayRectangle(rect1);

   system("pause");
   return 0;
}