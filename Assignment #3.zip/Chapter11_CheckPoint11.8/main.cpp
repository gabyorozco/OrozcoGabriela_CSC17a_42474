/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 4:52 PM
 */

#include <cstdlib>
#include <iostream>


using namespace std;


/*Write a structure declaration named Measurement , with the following members:
miles, an integer, meters, a long integer */
 

int main(int argc, char** argv) {

    struct Measurement{
        int miles;
        long meters;
    };
    return 0;
}

