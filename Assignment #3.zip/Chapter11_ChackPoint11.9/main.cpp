/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 4:56 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    struct Measurement{             // 11.8 part
        int miles;
        long meters;
    };
    
    
    struct Destination{             //New part
        string city;
        Measurement distance;
    };
Destination place;
    return 0;
}



