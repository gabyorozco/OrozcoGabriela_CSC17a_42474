 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: gabyo
 *
 * Created on March 25, 2018, 4:45 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Write a structure declaration to hold the following data about a savings account:
Account Number ( string object)
Account Balance ( double )
Interest Rate ( double )
Average Monthly Balance ( double ) */


int main(int argc, char** argv) {

struct Account{
    string acctNum;
    double acctBal;
    double intRate;
    double avgBal;
};
    return 0;
}


